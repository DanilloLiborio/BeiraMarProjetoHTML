
document.getElementById('btnFiltro').addEventListener('click', function(){
  alert('Filtro (placeholder) — aqui você pode abrir overlay de filtro.');
});

// Exemplo: adicionar handler para botões Exibir
document.querySelectorAll('.btn-exibir').forEach(function(btn){
  btn.addEventListener('click', function(){
    alert('Abrir detalhes do produto (placeholder).');
  });
});
